# AKExamOnline

JSP+Struts2+Hibernate+Json+Ajax

jQuery->第01章 Ajax:

http://www.w3school.com.cn/jquery/jquery_ref_ajax.asp

jQuery->第06章 JSON综合应用:

https://www.cnblogs.com/liubaozhe/p/4418741.html

Wdatepicker日期控件的使用指南:

http://blog.csdn.net/wanglei19880622/article/details/8051322

http://blog.csdn.net/zengxin2008/article/details/7248964#t66
